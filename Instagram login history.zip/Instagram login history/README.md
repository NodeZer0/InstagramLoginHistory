# Instagram Login history
This python program gets all login ips 

# 📎Modules Required
To install all the required modules use the following code:
<br/>
<b>pip install -r requirements.txt</b>

# Supported browsers

✔ Chrome<br/>
✔ Brave<br/>
✔ Edge (Chromium)


### 💵 Donations (Optional)
If you like my projects then consider making a small donation by clicking below button ^_^
<br/>
[![Donate](https://img.shields.io/badge/Donate-PayPal-blue.svg)](https://www.paypal.com/paypalme/henryrics)

#### Star the Repo in case you liked it :)
